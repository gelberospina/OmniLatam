package TestSQA.controller;

public class businessController {

}
