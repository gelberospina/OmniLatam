package TestSQA.step;/*
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class stepDefinition {

    WebDriver driver;

    @Before
    public void iniciar(){
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("Start-Maximized");
        options.addArguments("Enable-Automation");
        options.addArguments("--Incognito");
        driver = new ChromeDriver(options);
    }

    @After
    public void cerrar(){
        driver.close();
    }


    @Given("^estoy en la pagina requerida$")
    public void estoy_en_la_pagina_requerida() throws Throwable {
        driver.get("http://www.tp-link.com");
        System.out.println(driver.getTitle());
    }

    @And("^selecciono \"([^\"]*)\" de la seccion \"([^\"]*)\"$")
    public void selecciono_de_la_seccion(String producto, String seccion) throws Throwable {
        PageTP pageTP = new PageTP(driver);
        pageTP.seleccionarSubSeccion();
        pageTP.imprimirBanner();
    }

    @When("^se visualizan los routers$")
    public void se_visualizan_los_routers() throws Throwable {
        BusinessController businessController = new BusinessController(driver);
        businessController.listarElementos();
        
    }

    @And("^se filtra por rango$")
    public void se_filtra_por_rango() throws Throwable {
        PageTP pageTP = new PageTP(driver);
        pageTP.filtrar();
    }

    @And("^se vuelve a la pagina principal$")
    public void se_vuelve_a_la_pagina_principal() throws Throwable {
        PageTP pageTP = new PageTP(driver);
        pageTP.retornar();
    }

    @And("^se busca el producto identificado$")
    public void se_busca_el_producto_identificado() throws Throwable {
        PageTP pageTP = new PageTP(driver);
        pageTP.busqueda();
    }

    @Then("^se evidencia el producto$")
    public void se_evidencia_el_producto() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }




}*/