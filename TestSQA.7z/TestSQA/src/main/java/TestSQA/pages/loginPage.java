package TestSQA.pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginPage {
	private WebDriver driver;

}

@FindBy(xpath = "//ul[@class='nav clearfix']//a[@data-vars-event-category='Top-Menu-for-home']")
private WebElement btnSingIn;

@FindBy(xpath = "//a[@class='ga-click'][@data-vars-event-category='Top-Menu-wi-fi-routers']")
private WebElement nombreSubSeccion;

@FindBy(xpath = "//div[@class='tp-container tp-banner-slider-wrapper']//h1")
private WebElement banner;

@FindBy(xpath = "//li[@class='tp-filter-item'][2]//span[@class='tp-filter-cate-expand']")
private WebElement tituloFiltro;


public void clickBotonSingIn(){
    driver.manage().timeouts().implicitlyWait(10 , TimeUnit.SECONDS);
    btnSingIn.click();
    System.out.println("GIVEN");
}




