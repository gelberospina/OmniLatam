package TestSQA.pages;

public class formPage {

}


@FindBy(xpath = "//ul[@class='nav clearfix']//a[@data-vars-event-category='Top-Menu-for-home']")
private WebElement btnSingIn;
